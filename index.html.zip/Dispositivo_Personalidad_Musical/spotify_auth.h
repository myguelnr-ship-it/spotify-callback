/*
  =====================================================================
  spotify_auth.h
  =====================================================================
  Maneja TODO el proceso de login con Spotify usando PKCE, que es el
  método recomendado quando NO se puede guardar un Client Secret de
  forma segura (justo el caso de un ESP32 que cualquier usuario podría
  desarmar). Gracias a PKCE, el usuario solo necesita iniciar sesión
  con su cuenta de Spotify, sin tocar Client ID/Secret jamás.

  Se incluye en el .ino principal con: #include "spotify_auth.h"
  =====================================================================
*/

#ifndef SPOTIFY_AUTH_H
#define SPOTIFY_AUTH_H

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <mbedtls/sha256.h> // Para generar el "code_challenge" que pide PKCE

// ---------------------------------------------------------------
// CONFIGURACIÓN FIJA DE TU APP DE SPOTIFY (la creas UNA SOLA VEZ)
// ---------------------------------------------------------------
// Este Client ID es público y va igual en TODOS los dispositivos.
// No necesitas Client Secret gracias a PKCE.
const char* SPOTIFY_CLIENT_ID = "TU_CLIENT_ID_AQUI"; // <-- CAMBIA ESTO

// Redirect URI: como el ESP32 no puede ofrecer HTTPS (requisito de
// Spotify desde nov. 2025), usamos una página HTTPS gratuita y
// pública (GitHub Pages) que solo muestra el código para copiarlo
// manualmente y pegarlo en la página del ESP32.
const char* SPOTIFY_REDIRECT_URI = "https://TU_USUARIO.github.io/spotify-callback/"; // <-- CAMBIA ESTO

// ---------------------------------------------------------------
// VARIABLES GLOBALES DEL PROCESO DE LOGIN
// ---------------------------------------------------------------
String pkceCodeVerifier  = ""; // Cadena secreta generada localmente
String pkceCodeChallenge = ""; // Versión "hasheada" que se manda a Spotify
String spotifyAccessToken  = "";
String spotifyRefreshToken = "";

// =====================================================================
//  FUNCIÓN: generarCadenaAleatoria()
//  Crea una cadena aleatoria de cierta longitud usando caracteres
//  permitidos por el estándar PKCE (letras, números, - . _ ~)
// =====================================================================
String generarCadenaAleatoria(int longitud) {
  const char caracteres[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  String resultado = "";
  for (int i = 0; i < longitud; i++) {
    int indice = random(0, sizeof(caracteres) - 1);
    resultado += caracteres[indice];
  }
  return resultado;
}

// =====================================================================
//  FUNCIÓN: base64UrlEncode()
//  Convierte bytes crudos a texto Base64 "seguro para URL"
//  (reemplaza + por -, / por _, y quita el relleno =), que es el
//  formato exacto que pide el estándar PKCE para el code_challenge.
// =====================================================================
String base64UrlEncode(const uint8_t* datos, size_t longitud) {
  const char tabla[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  String salida = "";
  int i = 0;
  uint8_t arreglo3[3], arreglo4[4];

  while (longitud--) {
    arreglo3[i++] = *(datos++);
    if (i == 3) {
      arreglo4[0] = (arreglo3[0] & 0xfc) >> 2;
      arreglo4[1] = ((arreglo3[0] & 0x03) << 4) + ((arreglo3[1] & 0xf0) >> 4);
      arreglo4[2] = ((arreglo3[1] & 0x0f) << 2) + ((arreglo3[2] & 0xc0) >> 6);
      arreglo4[3] = arreglo3[2] & 0x3f;
      for (i = 0; i < 4; i++) salida += tabla[arreglo4[i]];
      i = 0;
    }
  }

  if (i) {
    for (int j = i; j < 3; j++) arreglo3[j] = 0;
    arreglo4[0] = (arreglo3[0] & 0xfc) >> 2;
    arreglo4[1] = ((arreglo3[0] & 0x03) << 4) + ((arreglo3[1] & 0xf0) >> 4);
    arreglo4[2] = ((arreglo3[1] & 0x0f) << 2) + ((arreglo3[2] & 0xc0) >> 6);
    for (int j = 0; j < i + 1; j++) salida += tabla[arreglo4[j]];
  }

  // Conversión a formato "URL-safe" que exige PKCE
  salida.replace("+", "-");
  salida.replace("/", "_");
  salida.replace("=", "");
  return salida;
}

// =====================================================================
//  FUNCIÓN: generarParPKCE()
//  Genera el code_verifier (secreto) y su code_challenge (hash SHA-256
//  en Base64Url), siguiendo exactamente el estándar que pide Spotify.
// =====================================================================
void generarParPKCE() {
  randomSeed(esp_random()); // Semilla aleatoria real del chip ESP32
  pkceCodeVerifier = generarCadenaAleatoria(64); // Entre 43 y 128 caracteres

  // Calculamos el hash SHA-256 del code_verifier
  uint8_t hash[32];
  mbedtls_sha256_context ctx;
  mbedtls_sha256_init(&ctx);
  mbedtls_sha256_starts(&ctx, 0); // 0 = usar SHA-256 (no SHA-224)
  mbedtls_sha256_update(&ctx, (const unsigned char*)pkceCodeVerifier.c_str(), pkceCodeVerifier.length());
  mbedtls_sha256_finish(&ctx, hash);
  mbedtls_sha256_free(&ctx);

  pkceCodeChallenge = base64UrlEncode(hash, 32);
}

// =====================================================================
//  FUNCIÓN: construirURLAutorizacion()
//  Arma la URL completa a la que debe ir el usuario para loguearse
//  con su cuenta de Spotify y autorizar el acceso.
// =====================================================================
String construirURLAutorizacion() {
  generarParPKCE(); // Generamos un par nuevo cada vez que alguien inicia el login

  String url = "https://accounts.spotify.com/authorize";
  url += "?client_id=" + String(SPOTIFY_CLIENT_ID);
  url += "&response_type=code";
  url += "&redirect_uri=" + String(SPOTIFY_REDIRECT_URI);
  url += "&code_challenge_method=S256";
  url += "&code_challenge=" + pkceCodeChallenge;
  url += "&scope=user-read-private"; // Permiso mínimo: solo identificar al usuario
  return url;
}

// =====================================================================
//  FUNCIÓN: intercambiarCodigoPorTokens()
//  Cuando Spotify regresa al ESP32 con un "code" en la URL, esta
//  función lo cambia por un Access Token + Refresh Token reales,
//  usando el code_verifier original como prueba de identidad (PKCE).
// =====================================================================
bool intercambiarCodigoPorTokens(String codigoRecibido) {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient https;

  if (!https.begin(client, "https://accounts.spotify.com/api/token")) {
    return false;
  }

  https.addHeader("Content-Type", "application/x-www-form-urlencoded");

  String body = "grant_type=authorization_code";
  body += "&code=" + codigoRecibido;
  body += "&redirect_uri=" + String(SPOTIFY_REDIRECT_URI);
  body += "&client_id=" + String(SPOTIFY_CLIENT_ID);
  body += "&code_verifier=" + pkceCodeVerifier; // Aquí NO se usa Client Secret

  int httpCode = https.POST(body);
  bool exito = false;

  if (httpCode == 200) {
    String respuesta = https.getString();
    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, respuesta);

    if (!error) {
      spotifyAccessToken  = doc["access_token"].as<String>();
      spotifyRefreshToken = doc["refresh_token"].as<String>();
      exito = true;
    }
  } else {
    Serial.print("❌ Error al intercambiar código por tokens. HTTP: ");
    Serial.println(httpCode);
    Serial.println(https.getString());
  }

  https.end();
  return exito;
}

// =====================================================================
//  FUNCIÓN: obtenerNombreUsuarioSpotify()
//  Petición simple de prueba: pide el nombre de perfil de Spotify
//  del usuario recién logueado, para mostrarlo en pantalla y
//  confirmar visualmente que el login funcionó.
// =====================================================================
String obtenerNombreUsuarioSpotify() {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient https;

  if (!https.begin(client, "https://api.spotify.com/v1/me")) {
    return "Usuario";
  }

  https.addHeader("Authorization", "Bearer " + spotifyAccessToken);
  int httpCode = https.GET();

  String nombre = "Usuario";
  if (httpCode == 200) {
    String respuesta = https.getString();
    JsonDocument doc;
    if (!deserializeJson(doc, respuesta)) {
      nombre = doc["display_name"].as<String>();
    }
  }

  https.end();
  return nombre;
}

#endif
