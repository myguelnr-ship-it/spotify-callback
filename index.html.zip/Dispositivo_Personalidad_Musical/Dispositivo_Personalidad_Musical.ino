/*
  =====================================================================
  Dispositivo_Personalidad_Musical.ino
  =====================================================================
  PROYECTO: Dispositivos portátiles que intercambian arquetipos de
  personalidad y gustos musicales vía ESP-NOW.

  ESTE ARCHIVO (Fase 2): Configuración del perfil vía página web.
  El ESP32 crea su propia red WiFi (Access Point). El usuario se
  conecta a ella con su celular, abre el navegador, y:
    1. Contesta un test de 16 preguntas
    2. Recibe su arquetipo + subtipo de personalidad
    3. Inicia sesión con su cuenta de Spotify (sin tocar IDs/Secrets)
    4. Elige sus géneros musicales favoritos
    5. Todo se guarda en LittleFS para usarse después en ESP-NOW

  IMPORTANTE: Sube este MISMO código a los 2 ESP32 — cada persona
  configura su propio dispositivo de forma independiente.
  =====================================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include "perfiles.h"      // Lógica de test, arquetipos y compatibilidad
#include "spotify_auth.h"  // Login con Spotify vía PKCE

// =====================================================================
//  CONFIGURACIÓN DEL ACCESS POINT (la red WiFi que crea el ESP32)
// =====================================================================
// Cambia el nombre si quieres distinguir el Dispositivo 1 del 2,
// por ejemplo "PerfilMusical-A" y "PerfilMusical-B"
const char* AP_SSID     = "PerfilMusical-Setup";
const char* AP_PASSWORD = "musica1234"; // Mínimo 8 caracteres

WebServer servidor(80); // Servidor web en el puerto 80 (HTTP estándar)

const char* RUTA_PERFIL = "/perfil.json"; // Aquí se guarda TODO el perfil final

// Variables temporales mientras el usuario hace el test
Puntuacion puntuacionActual;
int preguntaActual = 0;
int subtipoCalculado = -1;

// =====================================================================
//  SETUP
// =====================================================================
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n=== Iniciando configuración de perfil ===");

  if (!LittleFS.begin(true)) {
    Serial.println("❌ Error al iniciar LittleFS.");
    return;
  }

  // Si ya existe un perfil guardado, lo mostramos y NO levantamos
  // el portal de configuración (ya no hace falta).
  if (LittleFS.exists(RUTA_PERFIL)) {
    Serial.println("✅ Ya existe un perfil guardado. Mostrando resumen:");
    mostrarPerfilGuardado();
    Serial.println("\nSi quieres rehacer el perfil, borra la memoria");
    Serial.println("(Herramientas > Erase Flash > All Flash Contents) y vuelve a subir.");
    return;
  }

  // -------------------------------------------------------------
  // Creamos el Access Point: el ESP32 se convierte en su propio
  // router WiFi para que el usuario se conecte desde su celular.
  // -------------------------------------------------------------
  WiFi.softAP(AP_SSID, AP_PASSWORD);
  IPAddress ip = WiFi.softAPIP();
  Serial.println("📡 Red WiFi creada: " + String(AP_SSID));
  Serial.println("🔑 Contraseña: " + String(AP_PASSWORD));
  Serial.print("🌐 Conéctate y abre en el navegador: http://");
  Serial.println(ip);

  // -------------------------------------------------------------
  // Definimos todas las "rutas" (páginas) del servidor web
  // -------------------------------------------------------------
  servidor.on("/", manejarInicio);
  servidor.on("/test", manejarTest);
  servidor.on("/responder", manejarRespuesta);
  servidor.on("/resultado", manejarResultado);
  servidor.on("/conectar-spotify", manejarConectarSpotify);
  servidor.on("/pegar-codigo", manejarPegarCodigo);
  servidor.on("/procesar-codigo", manejarProcesarCodigo);
  servidor.on("/musica", manejarMusica);
  servidor.on("/guardar-musica", manejarGuardarMusica);
  servidor.on("/finalizado", manejarFinalizado);

  servidor.begin();
  Serial.println("✅ Servidor web iniciado.");
}

// =====================================================================
//  LOOP
// =====================================================================
void loop() {
  servidor.handleClient(); // Atiende cada petición que llega al servidor web
}

// =====================================================================
//  ESTILO CSS COMPARTIDO (se inyecta en cada página para diseño consistente)
// =====================================================================
// Paleta basada en los 4 arquetipos: fondo oscuro tipo "noche de concierto"
// con acentos cálidos. Tipografía con personalidad, sin librerías externas
// para no saturar la memoria del ESP32.
String estiloBase() {
  return R"(
  <style>
    * { box-sizing: border-box; margin:0; padding:0; }
    body {
      background: #15131a;
      color: #f4ede4;
      font-family: 'Georgia', 'Times New Roman', serif;
      min-height: 100vh;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      padding: 24px;
      text-align: center;
    }
    h1 {
      font-size: 1.8em; letter-spacing: 0.5px; margin-bottom: 8px;
      background: linear-gradient(90deg, #ff8a5c, #ffd166);
      -webkit-background-clip: text; background-clip: text; color: transparent;
    }
    p.subtitulo { color: #b9aebf; font-size: 0.95em; margin-bottom: 28px; font-family: Arial, sans-serif; }
    .tarjeta {
      background: #211d28; border: 1px solid #352f3d; border-radius: 14px;
      padding: 28px; max-width: 420px; width: 100%;
      box-shadow: 0 8px 24px rgba(0,0,0,0.35);
    }
    .boton {
      display: inline-block; margin-top: 18px; padding: 14px 28px;
      background: linear-gradient(90deg, #ff8a5c, #ffd166); color: #15131a;
      border: none; border-radius: 30px; font-family: Arial, sans-serif;
      font-weight: bold; font-size: 1em; text-decoration: none; cursor: pointer;
      width: 100%;
    }
    .boton:active { transform: scale(0.98); }
    .boton-secundario {
      background: transparent; color: #f4ede4; border: 1px solid #4a3f52;
    }
    .barra-progreso {
      width: 100%; height: 6px; background: #352f3d; border-radius: 4px;
      margin-bottom: 24px; overflow: hidden;
    }
    .barra-progreso-relleno {
      height: 100%; background: linear-gradient(90deg, #ff8a5c, #ffd166);
    }
    .pregunta-texto { font-size: 1.15em; margin-bottom: 22px; line-height: 1.4; }
    .opcion {
      display: block; width: 100%; padding: 14px; margin-bottom: 10px;
      background: #2a2530; border: 1px solid #4a3f52; border-radius: 10px;
      color: #f4ede4; font-family: Arial, sans-serif; font-size: 0.95em;
      text-decoration: none;
    }
    .emoji-grande { font-size: 3.5em; margin-bottom: 10px; }
    .nombre-subtipo { font-size: 1.6em; margin: 6px 0; color: #ffd166; }
    .nombre-arquetipo { font-size: 1em; color: #b9aebf; margin-bottom: 18px; font-family: Arial, sans-serif; }
    .lista-rasgos { text-align: left; font-family: Arial, sans-serif; font-size: 0.9em; margin-top: 16px; }
    .lista-rasgos div { margin-bottom: 8px; }
    .chip {
      display: inline-block; padding: 8px 14px; margin: 4px; border-radius: 20px;
      background: #2a2530; border: 1px solid #4a3f52; color: #f4ede4;
      font-family: Arial, sans-serif; font-size: 0.85em; cursor: pointer;
    }
    .chip.seleccionado {
      background: linear-gradient(90deg, #ff8a5c, #ffd166); color: #15131a; border: none; font-weight: bold;
    }
    .contenedor-chips { display: flex; flex-wrap: wrap; justify-content: center; margin: 16px 0; }
    input[type=text] {
      width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #4a3f52;
      background: #2a2530; color: #f4ede4; font-family: Arial, sans-serif; margin-top: 10px;
    }
  </style>
  )";
}

// =====================================================================
//  PÁGINA: INICIO
// =====================================================================
void manejarInicio() {
  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += estiloBase();
  html += "</head><body>";
  html += "<div class='tarjeta'>";
  html += "<div class='emoji-grande'>🎧</div>";
  html += "<h1>Encuentra tu Frecuencia</h1>";
  html += "<p class='subtitulo'>Responde un breve test, descubre tu arquetipo y conecta tu música.</p>";
  html += "<a class='boton' href='/test'>Comenzar test</a>";
  html += "</div></body></html>";
  servidor.send(200, "text/html", html);
}

// =====================================================================
//  PÁGINA: TEST (muestra UNA pregunta a la vez)
// =====================================================================
void manejarTest() {
  if (preguntaActual >= 16) {
    // Si ya se respondieron las 16, calculamos el resultado
    subtipoCalculado = calcularSubtipo(puntuacionActual);
    servidor.sendHeader("Location", "/resultado");
    servidor.send(303);
    return;
  }

  int progreso = (preguntaActual * 100) / 16;

  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += estiloBase();
  html += "</head><body>";
  html += "<div class='tarjeta'>";
  html += "<div class='barra-progreso'><div class='barra-progreso-relleno' style='width:" + String(progreso) + "%'></div></div>";
  html += "<div class='pregunta-texto'>" + String(PREGUNTAS[preguntaActual].texto) + "</div>";
  html += "<a class='opcion' href='/responder?r=si'>✅ Sí, totalmente</a>";
  html += "<a class='opcion' href='/responder?r=no'>❌ No, para nada</a>";
  html += "</div></body></html>";
  servidor.send(200, "text/html", html);
}

// =====================================================================
//  RUTA: RESPONDER (procesa la respuesta y avanza a la siguiente)
// =====================================================================
void manejarRespuesta() {
  String respuesta = servidor.arg("r");
  bool esSi = (respuesta == "si");
  int dimension = PREGUNTAS[preguntaActual].dimension;

  // Sumamos el punto a la letra correspondiente según la dimensión
  switch (dimension) {
    case 0: esSi ? puntuacionActual.E++ : puntuacionActual.I++; break;
    case 1: esSi ? puntuacionActual.S++ : puntuacionActual.N++; break;
    case 2: esSi ? puntuacionActual.T++ : puntuacionActual.F++; break;
    case 3: esSi ? puntuacionActual.J++ : puntuacionActual.P++; break;
  }

  preguntaActual++;
  servidor.sendHeader("Location", "/test");
  servidor.send(303); // Redirige de vuelta a /test para la siguiente pregunta
}

// =====================================================================
//  PÁGINA: RESULTADO (muestra el arquetipo + subtipo obtenido)
// =====================================================================
void manejarResultado() {
  Subtipo s = SUBTIPOS[subtipoCalculado];

  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += estiloBase();
  html += "</head><body>";
  html += "<div class='tarjeta'>";
  html += "<div class='emoji-grande'>" + String(EMOJI_ARQUETIPO[s.arquetipo]) + "</div>";
  html += "<div class='nombre-arquetipo'>Arquetipo " + String(NOMBRE_ARQUETIPO[s.arquetipo]) + "</div>";
  html += "<div class='nombre-subtipo'>" + String(s.nombre) + "</div>";
  html += "<div class='lista-rasgos'>";
  html += "<div>💪 <b>Fortalezas:</b><br>" + String(s.fortaleza1) + "<br>" + String(s.fortaleza2) + "</div>";
  html += "<div>⚠️ <b>A trabajar:</b><br>" + String(s.debilidad1) + "<br>" + String(s.debilidad2) + "</div>";
  html += "</div>";
  html += "<a class='boton' href='/conectar-spotify'>Conectar mi música 🎵</a>";
  html += "</div></body></html>";
  servidor.send(200, "text/html", html);
}

// =====================================================================
//  RUTA: CONECTAR SPOTIFY (muestra instrucciones + botón a Spotify)
// =====================================================================
void manejarConectarSpotify() {
  String urlAutorizacion = construirURLAutorizacion();

  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += estiloBase();
  html += "</head><body><div class='tarjeta'>";
  html += "<div class='emoji-grande'>🎵</div>";
  html += "<h1>Conecta tu Spotify</h1>";
  html += "<p class='subtitulo'>1. Toca el botón. 2. Inicia sesión y acepta. 3. Copia el código que te muestre la página. 4. Vuelve aquí y pégalo.</p>";
  html += "<a class='boton' href='" + urlAutorizacion + "' target='_blank'>Abrir login de Spotify</a>";
  html += "<a class='boton boton-secundario' href='/pegar-codigo'>Ya tengo mi código</a>";
  html += "</div></body></html>";
  servidor.send(200, "text/html", html);
}

// =====================================================================
//  PÁGINA: PEGAR CÓDIGO (campo de texto manual)
// =====================================================================
void manejarPegarCodigo() {
  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += estiloBase();
  html += "</head><body><div class='tarjeta'>";
  html += "<div class='emoji-grande'>📋</div>";
  html += "<h1>Pega tu código</h1>";
  html += "<p class='subtitulo'>Pega aquí el código completo que copiaste de la página anterior.</p>";
  html += "<form action='/procesar-codigo' method='GET'>";
  html += "<input type='text' name='codigo' placeholder='Pega el código aquí'>";
  html += "<button class='boton' type='submit'>Continuar</button>";
  html += "</form>";
  html += "</div></body></html>";
  servidor.send(200, "text/html", html);
}

// =====================================================================
//  RUTA: PROCESAR CÓDIGO (intercambia el código pegado por tokens)
// =====================================================================
void manejarProcesarCodigo() {
  if (servidor.hasArg("codigo")) {
    String codigo = servidor.arg("codigo");
    codigo.trim();
    bool exito = intercambiarCodigoPorTokens(codigo);

    if (exito) {
      servidor.sendHeader("Location", "/musica");
      servidor.send(303);
      return;
    }
  }

  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += estiloBase();
  html += "</head><body><div class='tarjeta'>";
  html += "<div class='emoji-grande'>😕</div>";
  html += "<h1>No se pudo conectar</h1>";
  html += "<p class='subtitulo'>Revisa que copiaste el código completo, sin espacios extra, e intenta de nuevo.</p>";
  html += "<a class='boton' href='/conectar-spotify'>Volver a intentar</a>";
  html += "</div></body></html>";
  servidor.send(200, "text/html", html);
}

// =====================================================================
//  PÁGINA: MÚSICA (selección de géneros tras login exitoso)
// =====================================================================
const char* GENEROS_DISPONIBLES[12] = {
  "Pop", "Rock", "Reggaetón", "Indie", "Hip-Hop", "Electrónica",
  "Jazz", "Banda/Regional", "R&B", "Metal", "Clásica", "Lo-fi"
};

void manejarMusica() {
  String nombreUsuario = obtenerNombreUsuarioSpotify();

  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += estiloBase();
  html += "<script>";
  html += "let seleccionados = [];";
  html += "function alternar(el, genero) {";
  html += "  el.classList.toggle('seleccionado');";
  html += "  let idx = seleccionados.indexOf(genero);";
  html += "  if (idx === -1) { seleccionados.push(genero); } else { seleccionados.splice(idx, 1); }";
  html += "  document.getElementById('generos_input').value = seleccionados.join(',');";
  html += "}";
  html += "</script>";
  html += "</head><body>";
  html += "<div class='tarjeta'>";
  html += "<div class='emoji-grande'>✅</div>";
  html += "<h1>Hola, " + nombreUsuario + "</h1>";
  html += "<p class='subtitulo'>Elige los géneros que más escuchas</p>";
  html += "<form action='/guardar-musica' method='GET'>";
  html += "<div class='contenedor-chips'>";
  for (int i = 0; i < 12; i++) {
    html += "<div class='chip' onclick=\"alternar(this,'" + String(GENEROS_DISPONIBLES[i]) + "')\">" + String(GENEROS_DISPONIBLES[i]) + "</div>";
  }
  html += "</div>";
  html += "<input type='hidden' name='generos' id='generos_input' value=''>";
  html += "<input type='text' name='artistas' placeholder='Tus 2-3 artistas favoritos (separados por coma)'>";
  html += "<button class='boton' type='submit'>Guardar mi perfil</button>";
  html += "</form>";
  html += "</div></body></html>";
  servidor.send(200, "text/html", html);
}

// =====================================================================
//  RUTA: GUARDAR MÚSICA (guarda TODO el perfil final en LittleFS)
// =====================================================================
void manejarGuardarMusica() {
  String generos = servidor.arg("generos");
  String artistas = servidor.arg("artistas");
  String nombreUsuario = obtenerNombreUsuarioSpotify();

  Subtipo s = SUBTIPOS[subtipoCalculado];

  // Construimos el documento JSON final con TODO el perfil
  JsonDocument doc;
  doc["nombre_usuario"] = nombreUsuario;
  doc["subtipo"] = s.nombre;
  doc["codigo_subtipo"] = s.codigo;
  doc["arquetipo_id"] = s.arquetipo;
  doc["arquetipo_nombre"] = NOMBRE_ARQUETIPO[s.arquetipo];

  // Convertimos la cadena "Pop,Rock,Indie" en un arreglo JSON real
  JsonArray arregloGeneros = doc["generos"].to<JsonArray>();
  int inicio = 0;
  for (int i = 0; i <= (int)generos.length(); i++) {
    if (i == (int)generos.length() || generos[i] == ',') {
      String g = generos.substring(inicio, i);
      if (g.length() > 0) arregloGeneros.add(g);
      inicio = i + 1;
    }
  }

  JsonArray arregloArtistas = doc["artistas"].to<JsonArray>();
  inicio = 0;
  for (int i = 0; i <= (int)artistas.length(); i++) {
    if (i == (int)artistas.length() || artistas[i] == ',') {
      String a = artistas.substring(inicio, i);
      a.trim();
      if (a.length() > 0) arregloArtistas.add(a);
      inicio = i + 1;
    }
  }

  // Guardamos también el Refresh Token de Spotify del usuario, por si
  // en el futuro queremos volver a pedir datos sin loguearse de nuevo.
  doc["spotify_refresh_token"] = spotifyRefreshToken;

  File archivo = LittleFS.open(RUTA_PERFIL, "w");
  if (archivo) {
    serializeJson(doc, archivo);
    archivo.close();
  }

  servidor.sendHeader("Location", "/finalizado");
  servidor.send(303);
}

// =====================================================================
//  PÁGINA: FINALIZADO
// =====================================================================
void manejarFinalizado() {
  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += estiloBase();
  html += "</head><body><div class='tarjeta'>";
  html += "<div class='emoji-grande'>🎉</div>";
  html += "<h1>¡Perfil listo!</h1>";
  html += "<p class='subtitulo'>Ya puedes acercar tu dispositivo a otro para descubrir su compatibilidad.</p>";
  html += "</div></body></html>";
  servidor.send(200, "text/html", html);
}

// =====================================================================
//  FUNCIÓN: mostrarPerfilGuardado()
//  Se usa cuando el ESP32 arranca y YA tiene un perfil guardado;
//  muestra el resumen por el Monitor Serie.
// =====================================================================
void mostrarPerfilGuardado() {
  File archivo = LittleFS.open(RUTA_PERFIL, "r");
  if (!archivo) return;

  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, archivo);
  archivo.close();

  if (error) {
    Serial.println("❌ Error al leer el perfil guardado.");
    return;
  }

  Serial.println("👤 Usuario: " + doc["nombre_usuario"].as<String>());
  Serial.println("🪪 Subtipo: " + doc["subtipo"].as<String>());
  Serial.println("🏷️ Arquetipo: " + doc["arquetipo_nombre"].as<String>());
  Serial.print("🎵 Géneros: ");
  for (JsonVariant g : doc["generos"].as<JsonArray>()) {
    Serial.print(g.as<String>() + " ");
  }
  Serial.println();
}
