/*
  =====================================================================
  Dispositivo_ESPNOW_Intercambio.ino
  =====================================================================
  FASE 3: Intercambio de perfiles por ESP-NOW.

  Sube este código DESPUÉS de que ambos ESP32 ya tengan su perfil
  guardado (es decir, después de completar el test + Spotify en el
  sketch "Dispositivo_Personalidad_Musical.ino").

  Qué hace:
  - Lee el perfil guardado en LittleFS (arquetipo + subtipo + géneros)
  - Transmite por ESP-NOW en modo broadcast (no hace falta conocer
    la MAC del otro dispositivo de antemano)
  - Al recibir el perfil del otro dispositivo, verifica si los
    arquetipos son compatibles (Ignición<->Resonancia, Estructura<->Eco)
  - Si SON compatibles: calcula un % de compatibilidad basado en el
    subtipo de cada quien, y muestra fortalezas/debilidades de la pareja
  - Si NO son compatibles: informa que no hay conexión y no intercambia
    música (tal como pediste)
  - Todo el resultado se muestra por el Monitor Serie (115200 baudios)
  =====================================================================
*/

#include <esp_now.h>
#include <WiFi.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include "perfiles.h" // Reutilizamos arquetipos, subtipos y la función de compatibilidad

const char* RUTA_PERFIL = "/perfil.json";
const int CANAL_ESPNOW = 1; // Ambos dispositivos deben usar el mismo canal

// =====================================================================
//  ESTRUCTURA DE DATOS QUE SE ENVÍA POR ESP-NOW
// =====================================================================
// ESP-NOW transmite máximo 250 bytes por paquete, así que mandamos
// solo lo esencial en una estructura compacta (no el JSON completo).
typedef struct {
  char nombreUsuario[20];
  int subtipoId;     // Índice 0-15 dentro del arreglo SUBTIPOS
  int arquetipoId;    // 0=Ignición, 1=Resonancia, 2=Estructura, 3=Eco
  char generos[4][16]; // Hasta 4 géneros musicales, 15 caracteres c/u
  int cantidadGeneros;
} PaqueteIntercambio;

PaqueteIntercambio miPerfil;
PaqueteIntercambio perfilRecibido;
bool yaIntercambiado = false; // Evita procesar el mismo intercambio varias veces

uint8_t direccionBroadcast[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// =====================================================================
//  SETUP
// =====================================================================
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n=== Modo Intercambio ESP-NOW ===");

  if (!LittleFS.begin(true)) {
    Serial.println("❌ Error al iniciar LittleFS.");
    return;
  }

  if (!LittleFS.exists(RUTA_PERFIL)) {
    Serial.println("❌ No hay perfil guardado. Primero sube el sketch de configuración y completa el test.");
    return;
  }

  cargarMiPerfilDesdeArchivo();

  // -------------------------------------------------------------
  // Inicializamos WiFi en modo estación (necesario para ESP-NOW,
  // aunque NO nos conectamos a ningún router real)
  // -------------------------------------------------------------
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_channel(CANAL_ESPNOW, WIFI_SECOND_CHAN_NONE);

  if (esp_now_init() != ESP_OK) {
    Serial.println("❌ Error al iniciar ESP-NOW.");
    return;
  }

  // Registramos las funciones que se ejecutan al enviar/recibir datos
  esp_now_register_send_cb(alEnviarDatos);
  esp_now_register_recv_cb(alRecibirDatos);

  // -------------------------------------------------------------
  // Agregamos la dirección de broadcast como "peer" (requisito de
  // ESP-NOW antes de poder enviar a esa dirección)
  // -------------------------------------------------------------
  esp_now_peer_info_t infoPeer = {};
  memcpy(infoPeer.peer_addr, direccionBroadcast, 6);
  infoPeer.channel = CANAL_ESPNOW;
  infoPeer.encrypt = false;

  if (esp_now_add_peer(&infoPeer) != ESP_OK) {
    Serial.println("❌ Error al agregar peer de broadcast.");
    return;
  }

  Serial.println("✅ ESP-NOW listo. Buscando otro dispositivo cercano...");
  Serial.println("📡 Mi MAC: " + WiFi.macAddress());
}

// =====================================================================
//  LOOP: transmite mi perfil cada 2 segundos hasta encontrar pareja
// =====================================================================
void loop() {
  if (!yaIntercambiado) {
    esp_now_send(direccionBroadcast, (uint8_t*)&miPerfil, sizeof(miPerfil));
    delay(2000); // Esperamos 2 segundos entre cada intento de transmisión
  }
}

// =====================================================================
//  FUNCIÓN: cargarMiPerfilDesdeArchivo()
//  Lee el perfil.json guardado en la Fase 2 y lo convierte en la
//  estructura compacta que se transmite por ESP-NOW.
// =====================================================================
void cargarMiPerfilDesdeArchivo() {
  File archivo = LittleFS.open(RUTA_PERFIL, "r");
  JsonDocument doc;
  deserializeJson(doc, archivo);
  archivo.close();

  String nombre = doc["nombre_usuario"].as<String>();
  nombre.toCharArray(miPerfil.nombreUsuario, 20);

  String codigoSubtipo = doc["codigo_subtipo"].as<String>();
  miPerfil.subtipoId = 0;
  for (int i = 0; i < 16; i++) {
    if (String(SUBTIPOS[i].codigo) == codigoSubtipo) {
      miPerfil.subtipoId = i;
      break;
    }
  }
  miPerfil.arquetipoId = doc["arquetipo_id"].as<int>();

  JsonArray generos = doc["generos"].as<JsonArray>();
  miPerfil.cantidadGeneros = 0;
  for (JsonVariant g : generos) {
    if (miPerfil.cantidadGeneros >= 4) break; // Máximo 4 por límite de espacio
    String genero = g.as<String>();
    genero.toCharArray(miPerfil.generos[miPerfil.cantidadGeneros], 16);
    miPerfil.cantidadGeneros++;
  }

  Serial.println("👤 Mi perfil cargado: " + nombre + " - " + String(SUBTIPOS[miPerfil.subtipoId].nombre));
}

// =====================================================================
//  CALLBACK: alEnviarDatos()
//  Se ejecuta automáticamente cada vez que se intenta enviar un paquete.
// =====================================================================
void alEnviarDatos(const uint8_t *macAddr, esp_now_send_status_t status) {
  // No imprimimos nada aquí para no saturar el Monitor Serie,
  // ya que se transmite cada 2 segundos en bucle.
}

// =====================================================================
//  CALLBACK: alRecibirDatos()
//  Se ejecuta automáticamente cuando llega un paquete de otro ESP32.
// =====================================================================
void alRecibirDatos(const esp_now_recv_info_t *info, const uint8_t *datos, int longitud) {
  if (yaIntercambiado) return; // Ya procesamos un intercambio, ignoramos más paquetes

  memcpy(&perfilRecibido, datos, sizeof(perfilRecibido));
  yaIntercambiado = true;

  procesarIntercambio();
}

// =====================================================================
//  FUNCIÓN: procesarIntercambio()
//  Compara mi arquetipo con el del dispositivo recién encontrado,
//  decide si son compatibles, calcula el % y muestra el resultado.
// =====================================================================
void procesarIntercambio() {
  Serial.println("\n📲 ¡Dispositivo encontrado!");
  Serial.println("👤 " + String(perfilRecibido.nombreUsuario) + " - " + String(SUBTIPOS[perfilRecibido.subtipoId].nombre));

  bool compatibles = sonArquetiposCompatibles(miPerfil.arquetipoId, perfilRecibido.arquetipoId);

  if (!compatibles) {
    Serial.println("\n🚫 ARQUETIPOS NO COMPATIBLES");
    Serial.println("   " + String(NOMBRE_ARQUETIPO[miPerfil.arquetipoId]) + " no conecta con " + String(NOMBRE_ARQUETIPO[perfilRecibido.arquetipoId]));
    Serial.println("   No se intercambiará información musical.");
    return;
  }

  // -------------------------------------------------------------
  // Calculamos el % de compatibilidad basado en el subtipo exacto.
  // Lógica: arquetipos compatibles ya dan una base del 70%.
  // Si además comparten algún género musical, sumamos puntos extra.
  // -------------------------------------------------------------
  int porcentaje = 70; // Base por tener arquetipos compatibles

  int generosCompartidos = 0;
  for (int i = 0; i < miPerfil.cantidadGeneros; i++) {
    for (int j = 0; j < perfilRecibido.cantidadGeneros; j++) {
      if (String(miPerfil.generos[i]) == String(perfilRecibido.generos[j])) {
        generosCompartidos++;
      }
    }
  }
  porcentaje += generosCompartidos * 7; // +7% por cada género en común
  if (porcentaje > 99) porcentaje = 99;  // Nunca mostramos 100% exacto, da más "juego"

  Subtipo miSubtipo = SUBTIPOS[miPerfil.subtipoId];
  Subtipo otroSubtipo = SUBTIPOS[perfilRecibido.subtipoId];

  Serial.println("\n✅ ¡ARQUETIPOS COMPATIBLES! " + String(EMOJI_ARQUETIPO[miPerfil.arquetipoId]) + " + " + String(EMOJI_ARQUETIPO[perfilRecibido.arquetipoId]));
  Serial.println("💞 Compatibilidad: " + String(porcentaje) + "%");

  Serial.println("\n--- Tu perfil (" + String(miSubtipo.nombre) + ") ---");
  Serial.println("💪 " + String(miSubtipo.fortaleza1));
  Serial.println("⚠️ " + String(miSubtipo.debilidad1));

  Serial.println("\n--- Su perfil (" + String(otroSubtipo.nombre) + ") ---");
  Serial.println("💪 " + String(otroSubtipo.fortaleza1));
  Serial.println("⚠️ " + String(otroSubtipo.debilidad1));

  Serial.println("\n🎵 Géneros en común: " + String(generosCompartidos));
  Serial.print("   Su música: ");
  for (int i = 0; i < perfilRecibido.cantidadGeneros; i++) {
    Serial.print(String(perfilRecibido.generos[i]) + " ");
  }
  Serial.println();

  Serial.println("\n=== INTERCAMBIO COMPLETO ===");
}
