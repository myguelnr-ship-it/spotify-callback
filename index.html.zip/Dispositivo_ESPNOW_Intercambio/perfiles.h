/*
  =====================================================================
  perfiles.h
  =====================================================================
  Este archivo contiene TODA la lógica de personalidad del proyecto:
  - Las 16 preguntas del test
  - Los 16 subtipos de personalidad (agrupados en 4 arquetipos)
  - Fortalezas y debilidades de cada subtipo
  - La tabla de compatibilidad entre arquetipos

  Se incluye en el .ino principal con: #include "perfiles.h"
  =====================================================================
*/

#ifndef PERFILES_H
#define PERFILES_H

#include <Arduino.h>

// =====================================================================
//  DIMENSIONES DE PERSONALIDAD (uso interno, el usuario nunca las ve)
// =====================================================================
// Cada pregunta suma puntos a una de 4 dimensiones, igual que en los
// tests de personalidad clásicos de 16 tipos:
//   EI -> Extroversión (E) vs Introversión (I)
//   SN -> Sensación (S) vs Intuición (N)
//   TF -> Pensamiento (T) vs Sentimiento (F)
//   JP -> Juicio/orden (J) vs Percepción/flexibilidad (P)
//
// Al final, combinamos las 4 letras dominantes para ubicar al usuario
// en 1 de los 16 subtipos definidos más abajo.

struct Puntuacion {
  int E = 0, I = 0;
  int S = 0, N = 0;
  int T = 0, F = 0;
  int J = 0, P = 0;
};

// =====================================================================
//  LAS 16 PREGUNTAS DEL TEST
// =====================================================================
// Cada pregunta tiene un texto y afecta una dimensión específica.
// "dimension" indica qué par de letras mide (0=EI, 1=SN, 2=TF, 3=JP)
// Si el usuario responde "Sí" (true), suma a la primera letra del par.
// Si responde "No" (false), suma a la segunda letra del par.

struct Pregunta {
  const char* texto;
  int dimension; // 0=EI, 1=SN, 2=TF, 3=JP
};

const Pregunta PREGUNTAS[16] = {
  { "¿Sueles sentirte con más energía después de estar rodeado de gente?", 0 },
  { "¿Te resulta fácil iniciar una conversación con un desconocido?", 0 },
  { "¿Prefieres planes espontáneos antes que agendas fijas?", 3 },
  { "¿Confías más en tu intuición que en datos concretos?", 1 },
  { "¿Disfrutas hablar de ideas abstractas más que de hechos prácticos?", 1 },
  { "¿Tomas decisiones importantes basándote más en lógica que en emociones?", 2 },
  { "¿Te describirías como una persona organizada y planificadora?", 3 },
  { "¿Te cuesta trabajo mantener una rutina fija por mucho tiempo?", 3 },
  { "¿Sueles priorizar la armonía del grupo sobre tener la razón?", 2 },
  { "¿Te recargas de energía estando en soledad más que en grupo?", 0 },
  { "¿Te emociona más imaginar el futuro que vivir el presente?", 1 },
  { "¿Sueles analizar los pros y contras antes de decidir algo?", 2 },
  { "¿Disfrutas tener el control y la última palabra en un grupo?", 0 },
  { "¿Te consideras una persona empática que se conecta con los sentimientos ajenos?", 2 },
  { "¿Prefieres terminar una tarea antes de empezar otra?", 3 },
  { "¿Te gusta experimentar con cosas nuevas aunque no tengan un propósito claro?", 1 }
};

// =====================================================================
//  LOS 16 SUBTIPOS DE PERSONALIDAD
// =====================================================================
// Cada subtipo pertenece a un arquetipo (0=Ignición, 1=Resonancia,
// 2=Estructura, 3=Eco) y tiene un código de 4 letras interno (no se
// muestra al usuario) que determina a cuál pertenece.

struct Subtipo {
  const char* nombre;        // Nombre creativo (lo que ve el usuario)
  const char* codigo;        // Código interno de 4 letras (ej. "ESFP")
  int arquetipo;              // 0=Ignición, 1=Resonancia, 2=Estructura, 3=Eco
  const char* fortaleza1;
  const char* fortaleza2;
  const char* debilidad1;
  const char* debilidad2;
};

const Subtipo SUBTIPOS[16] = {
  // ---------------- 🔥 IGNICIÓN ----------------
  { "El Chispa",        "ESFP", 0,
    "Contagia energía y alegría a quienes lo rodean",
    "Se adapta rápido a cualquier situación",
    "Le cuesta pensar en consecuencias a largo plazo",
    "Se aburre fácilmente con la rutina" },

  { "El Rebelde",        "ESTP", 0,
    "Actúa con valentía ante los retos",
    "Es directo y honesto, sin rodeos",
    "Puede ser impaciente con procesos lentos",
    "Tiende a actuar antes de pensar" },

  { "El Showman",        "ESFJ", 0,
    "Une a las personas y crea ambiente",
    "Es generoso y atento con los demás",
    "Busca aprobación externa con frecuencia",
    "Le cuesta manejar la crítica" },

  { "El Aventurero",     "ESTJ", 0,
    "Toma la iniciativa sin miedo",
    "Le encanta explorar lo desconocido",
    "Puede ser temerario al evaluar riesgos",
    "Se frustra con la espera o la lentitud" },

  // ---------------- 🌊 RESONANCIA ----------------
  { "El Soñador",        "INFP", 1,
    "Profundamente fiel a sus valores",
    "Tiene una imaginación rica y sensible",
    "Tiende a idealizar a las personas",
    "Le cuesta lidiar con críticas directas" },

  { "El Mediador",       "ENFJ", 1,
    "Excelente para resolver conflictos",
    "Inspira confianza con facilidad",
    "Descuida sus propias necesidades por ayudar a otros",
    "Le cuesta decir que no" },

  { "El Poeta",          "INFJ", 1,
    "Gran capacidad de empatía profunda",
    "Visión única y creativa del mundo",
    "Tiende al perfeccionismo emocional",
    "Se agota con el conflicto social" },

  { "El Inspirador",     "ENFP", 1,
    "Motiva a otros a soñar en grande",
    "Crea conexiones genuinas rápidamente",
    "Le cuesta mantener el enfoque en una sola cosa",
    "Puede sobre comprometerse" },

  // ---------------- 🌿 ESTRUCTURA ----------------
  { "El Guardián",       "ISFJ", 2,
    "Extremadamente leal y confiable",
    "Cuida los detalles que otros pasan por alto",
    "Le cuesta pedir ayuda cuando la necesita",
    "Evita el conflicto incluso cuando es necesario" },

  { "El Organizador",    "ESTJ2", 2,
    "Lidera con eficiencia y claridad",
    "Cumple lo que promete, siempre",
    "Puede ser inflexible ante el cambio",
    "Tiende a ser muy exigente con los demás" },

  { "El Tradicionalista", "ISTJ", 2,
    "Constante y de palabra firme",
    "Gran sentido de la responsabilidad",
    "Le cuesta adaptarse a lo inesperado",
    "Puede resistirse a nuevas ideas" },

  { "El Ejecutor",       "ESTJ3", 2,
    "Orientado a resultados concretos",
    "Disciplina envidiable para cumplir metas",
    "Prioriza la productividad sobre el descanso",
    "Le cuesta delegar tareas" },

  // ---------------- ✨ ECO ----------------
  { "El Estratega",      "INTJ", 3,
    "Visión a largo plazo excepcional",
    "Resuelve problemas complejos con lógica",
    "Puede parecer distante emocionalmente",
    "Le cuesta aceptar opiniones que contradicen su plan" },

  { "El Filósofo",       "INTP", 3,
    "Pensamiento profundo y original",
    "Cuestiona todo con curiosidad genuina",
    "Le cuesta pasar de la idea a la acción",
    "Puede perderse en el análisis excesivo" },

  { "El Inventor",       "ENTP", 3,
    "Creatividad para encontrar soluciones nuevas",
    "Disfruta el debate de ideas",
    "Le cuesta terminar lo que empieza",
    "Puede discutir solo por el gusto de hacerlo" },

  { "El Arquitecto",     "ENTJ", 3,
    "Gran capacidad de planeación estratégica",
    "Lidera proyectos con determinación",
    "Puede ser demasiado crítico consigo mismo",
    "Le cuesta mostrar vulnerabilidad" }
};

// =====================================================================
//  NOMBRES Y EMOJIS DE LOS ARQUETIPOS
// =====================================================================
const char* NOMBRE_ARQUETIPO[4] = { "Ignicion", "Resonancia", "Estructura", "Eco" };
const char* EMOJI_ARQUETIPO[4]  = { "🔥", "🌊", "🌿", "✨" };

// =====================================================================
//  TABLA DE COMPATIBILIDAD ENTRE ARQUETIPOS
// =====================================================================
// Ignición (0) <-> Resonancia (1)
// Estructura (2) <-> Eco (3)
// Cualquier otra combinación NO es compatible (incluyendo el mismo
// arquetipo con sigo mismo).

bool sonArquetiposCompatibles(int arquetipoA, int arquetipoB) {
  if (arquetipoA == 0 && arquetipoB == 1) return true;
  if (arquetipoA == 1 && arquetipoB == 0) return true;
  if (arquetipoA == 2 && arquetipoB == 3) return true;
  if (arquetipoA == 3 && arquetipoB == 2) return true;
  return false;
}

// =====================================================================
//  FUNCIÓN: calcularSubtipo()
//  Recibe el puntaje acumulado de las 16 preguntas y determina cuál
//  de los 16 subtipos le corresponde al usuario, comparando letra
//  por letra cuál predominó en cada dimensión.
// =====================================================================
int calcularSubtipo(Puntuacion &p) {
  char codigo[5];
  codigo[0] = (p.E >= p.I) ? 'E' : 'I';
  codigo[1] = (p.S >= p.N) ? 'S' : 'N';
  codigo[2] = (p.T >= p.F) ? 'T' : 'F';
  codigo[3] = (p.J >= p.P) ? 'J' : 'P';
  codigo[4] = '\0';

  // Buscamos qué subtipo tiene un código que EMPIEZA igual
  // (algunos códigos como "ESTJ2"/"ESTJ3" comparten letras base
  // pero representan matices distintos del mismo perfil ESTJ;
  // en ese caso usamos las dos preguntas extra de desempate
  // J/P y T/F acumuladas para elegir entre ellos).
  for (int i = 0; i < 16; i++) {
    String codigoSubtipo = String(SUBTIPOS[i].codigo);
    String codigoUsuario = String(codigo);
    if (codigoSubtipo == codigoUsuario || codigoSubtipo.startsWith(codigoUsuario)) {
      return i;
    }
  }

  // Si por algún motivo no hay match exacto (caso raro de empates),
  // devolvemos el subtipo cuyo código comparte más letras en común.
  int mejorIndice = 0;
  int mejorCoincidencias = -1;
  for (int i = 0; i < 16; i++) {
    String c = String(SUBTIPOS[i].codigo);
    int coincidencias = 0;
    for (int j = 0; j < 4; j++) {
      if (j < (int)c.length() && c[j] == codigo[j]) coincidencias++;
    }
    if (coincidencias > mejorCoincidencias) {
      mejorCoincidencias = coincidencias;
      mejorIndice = i;
    }
  }
  return mejorIndice;
}

#endif
